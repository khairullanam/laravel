<?php if (isset($component)) { $__componentOriginal1f9e5f64f242295036c059d9dc1c375c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1f9e5f64f242295036c059d9dc1c375c = $attributes; } ?>
<?php $component = App\View\Components\Layout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Layout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1f9e5f64f242295036c059d9dc1c375c)): ?>
<?php $attributes = $__attributesOriginal1f9e5f64f242295036c059d9dc1c375c; ?>
<?php unset($__attributesOriginal1f9e5f64f242295036c059d9dc1c375c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1f9e5f64f242295036c059d9dc1c375c)): ?>
<?php $component = $__componentOriginal1f9e5f64f242295036c059d9dc1c375c; ?>
<?php unset($__componentOriginal1f9e5f64f242295036c059d9dc1c375c); ?>
<?php endif; ?>
<section class="bg-white py-64">
  <div class="max-w-4xl mx-auto bg-white shadow-xl rounded-lg p-6" data-aos="fade-down" data-aos-duration="2000">
      <h1 class="text-4xl text-center font-bold text-black mb-6">E-BOOKS Paramadina</h1>

      <!-- Accordion for HMI -->
      <div class="accordion">
        <!-- HMI Accordion -->
        <div class="border-b mb-8">
            <button 
                onclick="toggleAccordion('hmiAccordion')" 
                class="w-full text-left text-lg font-semibold py-4 px-6 rounded-xl shadow-md text-white gradient focus:outline-none"
                id="hmiButton" data-aos="fade-down" data-aos-duration="1000"
            >
                Ke-HMI-an
            </button>
            <div id="hmiAccordion" class="hidden" data-aos="fade-down">
                <?php $__empty_1 = true; $__currentLoopData = $ebooks->where('kategori', 'hmi'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ebook): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="p-4 border-t flex items-center justify-between bg-gray-50 rounded-lg shadow-sm">
                        <div>
                            <p class="text-lg font-medium text-gray-900"><?php echo e($ebook->title); ?></p>
                            <p class="text-sm text-gray-600">Size: <?php echo e($ebook->size); ?> MB</p>
                        </div>
                        <a 
                            href="<?php echo e(Storage::url('public/' . $ebook->file)); ?>" 
                            download 
                            class="px-4 py-2 gradient text-white text-sm font-medium rounded-lg shadow"
                        >
                            Download
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="p-4 text-gray-600">Tidak ada e-book HMI tersedia.</div>
                <?php endif; ?>
            </div>
        </div>
    
        <!-- Ke-Islaman Accordion -->
        <div class="border-b mb-8">
            <button 
                onclick="toggleAccordion('keIslamanAccordion')" 
                class="w-full text-left text-lg font-semibold py-4 px-6 rounded-xl shadow-md text-white gradient focus:outline-none"
                id="keIslamanButton" data-aos="fade-down" data-aos-duration="1000"
            >
                Ke-Islaman
            </button>
            <div id="keIslamanAccordion" class="hidden" data-aos="fade-down">
                <?php $__empty_1 = true; $__currentLoopData = $ebooks->where('kategori', 'ke-islaman'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ebook): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="p-4 border-t flex items-center justify-between bg-gray-50 rounded-lg shadow-sm">
                        <div>
                            <p class="text-lg font-medium text-gray-900"><?php echo e($ebook->title); ?></p>
                            <p class="text-sm text-gray-600">Size: <?php echo e($ebook->size); ?> MB</p>
                        </div>
                        <a 
                            href="<?php echo e(Storage::url('public/' . $ebook->file)); ?>" 
                            download 
                            class="px-4 py-2 gradient text-white text-sm font-medium rounded-lg shadow"
                        >
                            Download
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="p-4 text-gray-600">Tidak ada e-book Ke-Islaman tersedia.</div>
                <?php endif; ?>
            </div>
        </div>
    
        <!-- Ke-Indonesiaan Accordion -->
        <div class="border-b mb-8">
            <button 
                onclick="toggleAccordion('keIndonesiaanAccordion')" 
                class="w-full text-left text-lg font-semibold py-4 px-6 rounded-xl shadow-md text-white gradient focus:outline-none"
                id="keIndonesiaanButton" data-aos="fade-down" data-aos-duration="1000"
            >
                Ke-Indonesiaan
            </button>
            <div id="keIndonesiaanAccordion" class="hidden" data-aos="fade-down">
                <?php $__empty_1 = true; $__currentLoopData = $ebooks->where('kategori', 'ke-indonesiaan'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ebook): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="p-4 border-t flex items-center justify-between bg-gray-50 rounded-lg shadow-sm">
                        <div>
                            <p class="text-lg font-medium text-gray-900"><?php echo e($ebook->title); ?></p>
                            <p class="text-sm text-gray-600">Size: <?php echo e($ebook->size); ?> MB</p>
                        </div>
                        <a 
                            href="<?php echo e(Storage::url('public/' . $ebook->file)); ?>" 
                            download 
                            class="px-4 py-2 gradient text-white text-sm font-medium rounded-lg shadow"
                        >
                            Download
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="p-4 text-gray-600">Tidak ada e-book Ke-Indonesiaan tersedia.</div>
                <?php endif; ?>
            </div>
        </div>
    
        <!-- Perempuan Accordion -->
        <div class="border-b mb-8">
            <button 
                onclick="toggleAccordion('perempuanAccordion')" 
                class="w-full text-left text-lg font-semibold py-4 px-6 rounded-xl shadow-md text-white gradient focus:outline-none"
                id="perempuanButton" data-aos="fade-down" data-aos-duration="1000"
            >
                Perempuan
            </button>
            <div id="perempuanAccordion" class="hidden" data-aos="fade-down">
                <?php $__empty_1 = true; $__currentLoopData = $ebooks->where('kategori', 'perempuan'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ebook): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="p-4 border-t flex items-center justify-between bg-gray-50 rounded-lg shadow-sm">
                        <div>
                            <p class="text-lg font-medium text-gray-900"><?php echo e($ebook->title); ?></p>
                            <p class="text-sm text-gray-600">Size: <?php echo e($ebook->size); ?> MB</p>
                        </div>
                        <a 
                            href="<?php echo e(Storage::url('public/' . $ebook->file)); ?>" 
                            download 
                            class="px-4 py-2 gradient text-white text-sm font-medium rounded-lg shadow"
                        >
                            Download
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="p-4 text-gray-600">Tidak ada e-book Perempuan tersedia.</div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script>
        function toggleAccordion(id) {
    const accordion = document.getElementById(id);
    const isHidden = accordion.classList.contains('hidden');
    if (isHidden) {
        accordion.classList.remove('hidden');
    } else {
        accordion.classList.add('hidden');
    }
}

    </script>

      <!-- Accordion for Ke-Islaman -->
      
  </div>
</section>





  
 
  
  
 <?php if (isset($component)) { $__componentOriginal99051027c5120c83a2f9a5ae7c4c3cfa = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal99051027c5120c83a2f9a5ae7c4c3cfa = $attributes; } ?>
<?php $component = App\View\Components\Footer::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Footer::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal99051027c5120c83a2f9a5ae7c4c3cfa)): ?>
<?php $attributes = $__attributesOriginal99051027c5120c83a2f9a5ae7c4c3cfa; ?>
<?php unset($__attributesOriginal99051027c5120c83a2f9a5ae7c4c3cfa); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal99051027c5120c83a2f9a5ae7c4c3cfa)): ?>
<?php $component = $__componentOriginal99051027c5120c83a2f9a5ae7c4c3cfa; ?>
<?php unset($__componentOriginal99051027c5120c83a2f9a5ae7c4c3cfa); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\latihan-laravel\resources\views/ebook-hmi.blade.php ENDPATH**/ ?>