<?php if (isset($component)) { $__componentOriginal1f9e5f64f242295036c059d9dc1c375c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1f9e5f64f242295036c059d9dc1c375c = $attributes; } ?>
<?php $component = App\View\Components\Layout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Layout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    
  
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1f9e5f64f242295036c059d9dc1c375c)): ?>
<?php $attributes = $__attributesOriginal1f9e5f64f242295036c059d9dc1c375c; ?>
<?php unset($__attributesOriginal1f9e5f64f242295036c059d9dc1c375c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1f9e5f64f242295036c059d9dc1c375c)): ?>
<?php $component = $__componentOriginal1f9e5f64f242295036c059d9dc1c375c; ?>
<?php unset($__componentOriginal1f9e5f64f242295036c059d9dc1c375c); ?>
<?php endif; ?>

<div class="bg-gray-50 py-24 sm:py-32 relative isolate overflow-hidden px-6 lg:overflow-visible lg:px-0">
  <div class="absolute inset-0 -z-10 overflow-hidden">
    <svg class="absolute left-[max(50%,25rem)] top-0 h-[64rem] w-[128rem] -translate-x-1/2 stroke-gray-200 [mask-image:radial-gradient(64rem_64rem_at_top,white,transparent)]" aria-hidden="true">
      <defs>
        <pattern id="e813992c-7d03-4cc4-a2bd-151760b470a0" width="200" height="200" x="50%" y="-1" patternUnits="userSpaceOnUse">
          <path d="M100 200V.5M.5 .5H200" fill="none" />
        </pattern>
      </defs>
      <svg x="50%" y="-1" class="overflow-visible fill-gray-50">
        <path d="M-100.5 0h201v201h-201Z M699.5 0h201v201h-201Z M499.5 400h201v201h-201Z M-300.5 600h201v201h-201Z" stroke-width="0" />
      </svg>
      <rect width="100%" height="100%" stroke-width="0" fill="url(#e813992c-7d03-4cc4-a2bd-151760b470a0)" />
    </svg>
  </div>
  <div class="mx-auto max-w-8xl px-6 lg:px-8">
    <p class="mx-auto mt-2 max-w-3xl text-center text-4xl font-semibold tracking-tight text-gray-950 sm:text-5xl">
      SEJARAH PERJUANGA HMI
    </p>

    <div class="mt-12 gap-6 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
      <!-- Item 1: Artikel Utama -->
      <article class="flex mx-auto max-w-4xl flex-col items-start justify-between col-span-2">
        <div class="group relative">
          <h1 class="mt-3 mb-4 text-3xl font-semibold text-gray-900">
            <span class="absolute inset-0"></span>
            A. SEJARAH BERDIRINYA HMI
          </h1>
          <div class="text-justify leading-relaxed text-gray-700">
            <p class="mb-4">Himpunan Mahasiswa Islam (HMI) didirikan oleh Lafran Pane yang pada saat itu genap berusia 25 tahun beserta 14 temannya yaitu Karnoto Zarkasyi, Dahlan Husein, Siti Zainab, Maisaroh Hilal, Soewali, Yusdi Ghozali, Mansyur, Anwar, Hasan Basri, Marwan, Zulkarnaen, Tayeb Razak, Toha Mashudi, dan Bidron Hadi. HMI berdiri pada tanggal 05 Februari 1947 bertepatan dengan 14 Rabiul Awwal 1366 H bertempat di Sekolah Tinggi Islam yang saat ini berganti nama menjadi Universitas Islam Indonesia di Yogyakarta</p>
          </div>
          <div class="text-justify leading-relaxed text-gray-700">
            <p class="mb-4">Tentang sosok Lafran Pane, dapat diceritakan secara garis besarnya antara lain bahwa Pemuda Lafran Pane lahir di Sipirok Tapanuli Selatan, Sumatera Utara. Beliau adalah anak seorang Sutan Pangurabaan Pane tokoh pergerakan nasional “serba komplit” dari Sipirok, Tapanuli Selatan.</p>
          </div>
          <div class="text-justify leading-relaxed text-gray-700">
            <p class="mb-4">Lafaran Pane adalah sosok yang tidak mengenal lelah dalam proses pencarian jati dirinya, dan secara kritis mencari kebenaran sejati. Lafran Pane kecil, remaja dan menjelang dewasa yang nakal, pemberontak, dan “bukan anak sekolah yang rajin” adalah identitas fundamental Lafran sebagai ciri paling menonjol dari Kemerdekaan. Sebagai figur pencarai sejati, independensi Lafran terasah, terbentuk, dan sekaligus teruji, di lembaga-lembaga pendidikan yang tidak Ia lalui dengan “Normal” dan “lurus” itu (Walau Pemuda Lafran Pane yang tumbuh dalam lingkungan nasionalis-muslim terpelajar pernah juga menganyam pendidikan di Pesantren Ibtidaiyah, Wusta dan sekolah Muhammadiyah) pada hidup berpetualang di sepanjang jalanan Kota Medan, terutama di kawasan Jalan Kesawan. pada kehidupan dengan tidur tidak menuntu; pada kaki-kaki lima dan kaisar pertokoan; juga pada kehidupan yang Ia jalani dengan menjual karcis bioskop, menjual es lilin, dll.</p>
          </div>
          <div class="text-justify leading-relaxed text-gray-700">
            <p class="mb-4">Dari perjalanan hidup Lafran dapat diketahui bahwa struktur fundamental independensi diri Lafran terletak pada kesediaan dan keteguhan Dia untuk terus secara kritis mencari kebenaran sejati dengan tanpa lelah, dimana saja, kepada saja, dan kapan saja.</p>
          </div>
          <div class="text-justify leading-relaxed text-gray-700">
            <p class="mb-4">HMI didirikan oleh Lafran Pane tidak terlepas dari kondisi kebangsaan, umat islam di Indonesia serta kondisi mahasiswa pada saat itu yang menyebabkan Lafran Pane gelisah terhadap kondisi tersebut sehingga melahirkan Himpunan Mahasiswa Islam (HMI).</p>
          </div>
          <div class="text-justify leading-relaxed text-gray-700">
            <p class="mb-4">Latar belakang pemikirannya dalam berdirinya HMI adalah: “Melihat dan menyadari keadaan kehidupan mahasiswa yang beragama Islam pada waktu itu, yang pada umumnya belum memahami dan mengamalkan ajaran agamanya. Yang demikian adalah akibat dari sitem Keadaan pendidikan dan kondisi masyarakat pada waktu itu. Oleh karena itu perlu dibentuk organisasi untuk memperbaiki keadaan tersebut. Organisasi mahasiswa ini harus mempunyai kemampuan untuk mengikuti alam pikiran mahasiswa yang selalu menginginkan inovasi atau pembaharuan dalam segala bidang, termasuk pemahaman dan penghayatan ajaran agamanya, yaitu agama Islam. Tujuan tersebut tidak akan terlaksana jika NKRI tidak merdeka, rakyatnya melarat. Maka organisasi ini harus ikut mempertahankan Negara Republik Indonesia hingga ke dalam dan ke luar, serta ikut memperhatikan dan mengusahakan kemakmuran rakyat”</p>
          </div>
          <div class="text-justify leading-relaxed text-gray-700">
            <p class="mb-4">Namun demikian, secara keseluruhan Latar Belakang Munculnya Pemikiran dan Berdirinya HMI dapat ditampilkan secara garis besar karena faktor-faktor sebagai berikut:</p>
          </div>
          <div class="text-justify leading-relaxed text-gray-700">
            <ol class="list-decimal pl-12 mb-4">
              <li>Penjajahan Belanda atas Indonesia dan Tuntutan Perang Kemerdekaan
                <ol class="list-disc pl-6 mt-2">
                  <li>Aspek Politik: Indonesia menjadi objek jajahan Belanda</li>
                  <li>Aspek Pemerintahan: Indonesia berada di bawah pemerintahan kerajaan Belanda</li>
                  <li>Aspek Hukum: Hukum berlaku diskriminatif</li>
                  <li>Aspek pendidikan: Proses pendidikan sangat dikendalikan oleh Belanda.</li>
                  <li>Aspek ekonomi: Bangsa Indonesia berada dalam kondisi ekonomi lemah</li>
                  <li>Aspek Kebudayaan: masuk dan berkembangnya kebudayaan yang bertentangan dengan kepribadian Bangsa Indonesia</li>
                  <li>Aspek Hubungan keagamaan: Masuk dan berkembagnya Agama Kristen di Indonesia, dan Umat Islam mengalami kemunduran</li>
                </ol>
              </li>
              <li>Adanya Kesenjangan dan kejumudan umat dalam pengetahuan, pemahaman, dan pengamalan ajaran Islam.</li>
              <li>Kebutuhan akan pemahaman dan penghayatan Keagamaan</li>
              <li>Munculnya polarisasi politik.</li>
              <li>Berkembangnya faham dan ajaran komunis</li>
              <li>Kedudukan perguruan tinggi dan dunia kemahasiswaan yang strategis</li>
              <li>Kemajuan Bangsa Indonesia</li>
              <li>Tuntutan modernisasi dan tantangan masa depan</li>
            </ol>
          </div>  
          <h1 class="mt-3 mb-4 text-3xl font-semibold text-gray-900">
            <span class="absolute inset-0"></span>
            B.	FASE-FASE PERJUANGAN HMI
          </h1>        
          <div class="text-justify leading-relaxed text-gray-700">
            <p class="mb-4"><b>Fase I: Konsolidasi Spiritual dan Proses Berdirinya HMI (1946)</b></p>
            <p class="mb-4">Bermula dari latar belakang munculnya pemikiran dan berdirinya HMI serta kondisi obyektif yang mendorongnya, maka rintisan untuk mendirikan HMI muncul di bulan November 1946. Permasalahan yang dapat diangkat dari latar belakang berdirinya HMI, merupakan suatu kenyataan yang harus diantisipasi dan dijawab secara cepat dan konkrit dan menunjukkan apa sebenarnya Islam itu. Maka pembaharuan pemikiran di kalangan umat Islam bangsa Indonesia suatu keniscayaan.</p>
            <p class="mb-4"><b>Fase II: Berdirinya dan Pengokohan (5 Februari – 30 November 1947)</b></p>
            <p class="mb-4">Selama lebih kurang sembilan bulan, reaksi-reaksi terhadap HMI barulah berakhir. Masa sembilan bulan itu dipergunakan untuk menjawab berbagai reaksi dan tantangan silih berganti, yang semuanya itu untuk mengokohkan eksistensi HMI sehingga dapat berdiri tegar dan kokoh. Maka diadakanlah berbagai aktivitas untuk popularisasi organisasi dengan mengadakan ceramah-ceramah ilmiah dan rekreasi malam-malam kesenian.</p>
            <p class="mb-4">Di bidang organisasi, HMI mulai mendirikan cabang-cabang baru seperti Klaten, Solo, dan Yogyakarta. Pengurus HMI bentukan 5 Februari 1947 otomatis menjadi PB HMI pertama dan merangkap menjadi Pengurus HMI Cabang Yogyakarta I. Ada kesan bahwa keanggotaan HMI hanya untuk mahasiswa Sekolah Tinggi Islam (STI). Untuk menghilangkan anggapan yang keliru itu, tanggal 22 Agustus 1947, PB HMI diresuffle. Ketua Lafran Pane digantikan oleh H.M. Mintaredja dari Fakultas Hukum BPT GM, sedankan Lafran Pane menjadi Wakil Ketua merangkap Ketua HMI Cabang Yogyakarta. Sejak itu mahasiswa BPT GM, STT mulai masuk dan berbondong-bondong menjadi anggota HMI. Di Yogyakarta tanggal 30 November 1947 diadakan Kongres I HMI.</p>
            <p class="mb-4"><b>Fase III: Perjuangan Bersenjata, Perang Kemerdekaan, Menghadapi Penghianatan dan Pemberontakan PKI (1947-1949)</b></p>
            <p class="mb-4">Seiring dengan tujuan HMI yang digariskan sejak awal berdirinya, maka konsekuensinya dalam masa perang kemerdekaan, HMI terjun ke gelanggang medan pertempuran melawan Belanda, membantu pemerintah baik langsung maupun memegang senjata bedil dan bambu runcing sebagai staf penerangan, penghubung dan lain-lain.</p>
            <p class="mb-4">Untuk menghadapi pemberontakan Madiun 18 September 1948, Ketua PMI/Wakil Ketua PB HMI Ahmad Tirtosudiro membentuk Corps Mahasiswa (CM), dengan Komandan Hartono, Wakil Komandan Ahmad Tirtosudiro, ikut membantu pemerintah menumpas pemberontakan Partai Komunis Indonesia (PKI) di Madiun dengan menggerakkan anggota CM ke gunung-gunung, memperkuat aparat pemerintah. Sejak itulah dendam PKI terhadap HMI tertanam dan terus berlanjut sampai puncaknya pada tahun 1964-1965 yaitu gerakan pengganyangan terhadap HMI menjelang meletusnya Gestapu/PKI 1965.</p>
            <p class="mb-4">Pada fase ini berlangsung peringatan ulang tahun pertama HMI di Bangsal Kepatihan tanggal 6 Februari 1948. Panglima Angkatan Perang Republik Indonesia Jenderal Sudirman memberi sambutan pada peringatan tersebut atas nama pemerintah Republik Indonesia. Jenderal Sudirman selain mengartikan HMI sebagai Himpunan Mahasiswa Islam, HMI juga diartikannya sebagai Harapan Masyarakat Indonesia. Karena mayoritas bangsa Indonesia beragama Islam, HMI juga diartikan sebagai Harapan Masyarakat Islam Indonesia.</p>
            <p class="mb-4">Pada fase ini juga berlangsung Kongres Muslim Indonesia II di Yogyakarta tanggal 20 sampai dengan 25 Desember 1949. Kongres itu dihadiri oleh 185 organisasi, alim ulama dan intelegensia seluruh Indonesia. Di antara tujuh dari keputusannya dibidang organisasi salah satu keputusannya adalah memutuskan bahwa: Hanya satu organisasi mahasiswa Islam, yaitu Himpunan Mahasiswa Islam (HMI) yang bercabang di tiap-tiap kota yang ada sekolah tinggi.</p>
            <p class="mb-4"><b>Fase IV: Pembinaan dan Pengembangan Organisasi (1950-1963)</b></p>
            <p class="mb-4">Selama anggota HMI banyak yang terjun ke gelanggang medan pertempuran membantu pemerintah mengusir penjajah, selama itu pula pembinaan organisasi HMI terabaikan. Namun hal itu dilaksanakan dengan sadar, karena itu semua untuk merealisir tujuan HMI sendiri, serta dwitugasnya yakni tugas agamanya dan tugas bangsanya. Maka dengan adanya pengakuan kedaulatan rakyat tanggal 27 Desember 1949, mahasiswa yang berminat melanjutkan kuliahnya bermunculan di Yogyakarta.</p>
            <p class="mb-4">Sejak tahun 1950, dilaksanakan usaha-usaha konsolidasi organisasi sebagai masalah besar sepanjang masa. Bulan Juli 1951 PB HMI dipindahkan dari Yogyakarta ke Jakarta. Diantara usaha-usaha yang dilaksanakan selama tiga belas tahun itu antara lain : Pembentukan cabang-cabang baru, Menerbitkan majalah sejak 1 Agustus 1954 (Sebelumnya terbit Criterium, Cerdas dan tahun 1959 menerbitkan majalah Media), Sudah tujuh kali Kongres HMI, Pengesahan atribut HMI seperti lambang, bendera, muts, hymne HMI, Merumuskan tafsir asas HMI, Pengesahan kepribadian HMI, Pembentukan Badan Koordinasi (BADKO) HMI, Menentukan metode pelatihan (Training) HMI., Pembentukan lembaga-lembaga HMI di bidang ekstern, Pendayagunakan PPMI., Menghadapi Pemilihan Umum (Pemilu) I tahun 1955, Penegasan Independensi HMI, Mendesak pemerintah supaya mengeluarkan UU PT, tuntutan agar pendidikan agama sejak dari Sekolah Rakyat (SR) sampai Perguruan Tinggi, Mengeluarkan konsep “peranan agama dalam pembangunan, dan lain-lainya.</p>
            <p class="mb-4">Selain masa internal, muncul pula persoalan eksternal yang sangat menonjol. Justru karena keberhasilan HMI melaksanakan konsolidasi organisasi ada golongan yang iri dan tidak senang kepada HMI yaitu Partai Komunis Indonesia (PKI).</p>
            <p class="mb-4">Tidak dibubarkan dan dilarangnya PKI akibatnya pemberontakan PKI di Madiun tahun 1948, PKI otomatis mempunyai kesempatan untuk bangkit kembali. Tanggal 21 Februari tahun 1957, Presiden Soekarno mengumumkan konsepsinya supaya kabinet berkaki empat dengan unsur PNI, Masyumi, NU dan PKI (sebagai 4 besar pemenang pemilu 1955). Berikutnya di Moscow tanggal 19 November 1957 dicetuskanlah Manfesto Moscow, yaitu satu program untuk mengkomunikasikan Indonesia. Akibat itu semua, PKI tampil sebagai partai pemerintah. Masyumi, akibat penentangan terhadap kebijakan politik Presiden Soekarno, dengan Manipol Usdeknya, dengan Keputusan Presiden nomor 200: tanggal 17 Agustus tahun 1960 Masyumi dipaksa bubar.</p>
            <p class="mb-4">Untuk menghadapi perkembangan politik, Kongres V HMI di Medan tanggal 24-31 Desember 1957 mengeluarkan dua sikap antara yaitu: Haram hukumnya menganut ajaran dan paham komunikasi karena bertentangan Islam, yang kedua, Menuntut supaya Islam sebagai dasar negara.</p>
            <p class="mb-4"><b>Fase V: Tantangan I (1964-1965)</b></p>
            <p class="mb-4">Dendam PKI terhadap HMI yang tertanam karena keikutsertaan HMI dalam menumpas pemberontakan PKI di Madiun tahun 1948, menempatkan HMI sebagai organisasi yang harus bubar, karena dianggap sebagai penghalang bagi tercapainya tujuan PKI. Untuk itulah dilaksanakanlah berbagai usaha untuk membubarkan HMI.</p>
            <p class="mb-4">Sesuai hasil Kongres II Consentrasi Gerakan Mahasiswa Indonesia (CGMI), organisasi underbow PKI di Salatiga, Juni 1961, untuk melekuidisi HMI. PKI, CGMI dan organisasi lainnya yang seideologi mulai melakukan gerakan pembubaran HMI disokong seluruh simpatisan dari tiga  partai besar yaitu Partai Komunis Indonesia (PKI), Partai Indonesia (PARTINDO) dan Partai Nasional Indonesia (PNI) dan juga seluruh underbow ketiga partai tersebut yang semuanya berjumlah 42 partai. Untuk membubarkan HMI sekitar bulan Maret 1965, dibentuk Panitia Aksi Pembubaran HMI di Jakarta yang terdiri dari CGMI, GMNI, GRMINDO, GMD, MMI, Pemuda Marhaenis, Pemuda Rakyat, Pemuda Indonesia, PPI, dan APPI.</p>
            <p class="mb-4">Menjawab tantangan ini, Generasi Muda Islam (GEMUIS) yang terbentuk tahun1964 membentuk Panitia Solidaritas Pembebelaan HMI, yang terdiri dari unsur-unsur pemuda, pelajar, mahasiswa Islam seluruh Indonesia. Bagi umat Islam, HMI merupakan taruhan terakhir yang harus dipertahankan setelah sebelumnya Masyumi dibubarkan. Kalau HMI sampai dibubarkan, maka satu-persatu dari organisasi Islam akan terkena sapu pembubaran.</p>
            <p class="mb-4">Namun gerakan pembubaran HMI ini gagal justeru dipuncak usaha-usaha pembubarannya. Dalam acara penutupan Kongres CGMI tanggal 29 September 1965 di Istora Senayan. Meski PKI terus melakukan provokasi kepada Presiden Soekarno, seperti diungkapkan DN. Aidit, “Kalau anggota CGMI tidak bisa membubarkan HMI, anggota CGMI yang laki-laki lebih pakai kain sarung saja... kalau semua front (garis depan-peny) sudah minta, Presiden akan membubarkan HMI”. Namun ternyata HMI tidak dibubarkan, bahkan dengan tegas Presiden Soekarno mengungkapkan dalam pidatonya: “Pemerintah mempunyai kebijakan untuk memberikan kesempatan seluas-luasnya kepada kehidupan organisasi mahasiswa yang revolusioner. Tapi kalau organisasi mahasiswa yang menyeleweng itu menjadi kontra revolusi umpamanya HMI, aku sendiri yang akan membubarkannya. Demikian pula kalau CGMI menyeleweng menjadi kontra revolusi juga akan kububarkan”.</p>
            <p class="mb-4">Karena gagal usaha untuk membubarkan HMI, maka PKI sudah siap bermain kekerasan. PKI takut didahului umat Islam untuk merebut kekuasaan dari pemerintahan yang sah, maka meletuslah Pemberontakan G 30 S/PKI 1965.</p>
            <p class="mb-4"><b>Fase VI: Kebangkitan HMI Sebagai Pejuang Orde Baru dan Pelopor Kebangkitan Angkatan ’66 (1966-1968)</b></p>
            <p class="mb-4">Pada fase ini HMI mengalami dan melewati tantangannya, yaitu; tanggal 1 Oktober adalah tugu pemisah antara Orde Lama dan Orde Baru. Apa yang disinyalir PKI, seandainya PKI gagal membubarkan PKI, maka HMI akan tampil kedua kalinya menumpas pemberontakan PKI dan itu benar-benar terjadi. Wakil Ketua PB HMI Mar’ie Muhammad, pada tanggal 25 Oktober 1965 mengambil inisiatif mendirikan Kesatuan Aksi Mahasiswa Indonesia (KAMI), sebagaimana yang dilakukan oleh Wakil Ketua PB HMI Ahmad Tirtosudiro membentuk Corps Mahasiswa (CM) untuk menghadapi pemberontakan PKI di Madiun. Tritura 10 Januari 1966: “Bubarkan PKI, Reatol Kabinet dan Turunkan Harga”. Surat Perintah Sebekas Maret 1966. Dibubarkan dan dilarangnya PKI tanggal 12 Maret 1966. Kabinet Ampera terbentuk, HMI diajak hearing pembentukan kabinet, dan alumni HMI masuk dalam kabinet.</p>
            <p class="mb-4"><b>Fase VII: Partisipasi HMI Dalam Pembangunan (1969-1970)</b></p>
            <p class="mb-4">Setelah Orde Baru mantap dan Pancasila serta Undang-Undang Dasar 1945 sudah dilaksankan secara murni dan konsekuen, maka sejak tanggal 1 April 1969 dimulailah rencana pembangunan lima tahun (Repelita-peny) dan sudah menyelesaikan pembangunan 25 tahun pertama, kemudian menyusul pembangunan 25 tahun kedua. Pembangunan Indonesia menuju masyarakat adil dan makmur bukanlah pekerjaan mudah, tetapi sebaliknya merupakan pembangunan raksasa (yang sangat sulit-peny) sebagai usaha kemanusiaan yang tidak habis-habisnya. Partisipasi segenap warga negara sangat dibutuhkan. HMI pun sesuai dengan lima aspek pemikirannya, telah memberikan sumbangan dan partisipasinya dalam pembangunan: (a). Partisipasi dalam pembentukan suasan, situasi dan iklim yang memungkinkan dilaksanakannya pembangunan, (b). Partisipasi dalam pemberian konsep-konsep di berbagai aspek pemikiran; (pertisipasi dalam bentuk langsung dari pembangunan).</p>
            <p class="mb-4"><b>FaseVIII: Pergolakan dan Pembaharuan Pemikiran (1970-1998)</b></p>
            <p class="mb-4">Selama kurun waktu Orde Lama (1959-1965) kebebasan mengeluarkan pendapat baik yang bersifat akademis terlebih-lebih politik terkekang dengan ketat. Suasana itu berubah tatkala Orde Baru muncul, walaupun kebebasan hakiki belum diperoleh sebagaimana mestinya. Sama halnya dipenghujung pemerintahan Soeharto dianggap sebagai suatu perbedaan yang tidak pada tempatnya (tidak ada keadilan-peny). Namun walaupun demikian, kebebasan datang, kondisi terbatas dapat dimanfaatkan, baik yang berkaitan dengan agama, akademik, dan politik. Kejumudan dan suasana tertekan pada masa Orde Lama mulai cair terutama dalam pembaharuan pemikiran Islam yang dipandang sebagai suatu keharusan, sebagai jawaban terhadap berbagai masalah untuk memenuhi kebutuhan kontemporer. Hal seperti itu muncul dikalangan HMI dan mencapai puncaknya pada tahun 1970. Tatkala Nurcholis Madjid (dikenal panggilan Cak Nur-peny) menyampaikan ide pembaharuannya dengan topik Keharusan Pembaharuan Pemikiran Dalam Islam Dan Masalah Integrasi Umat. Sikap itu diambil, karena apabila kondisi ini dibiarkan mengakibatkan persoalan-persoalan umat yang terbelenggu selama ini, tidak akan memperoleh jawaban yang efektif.</p>
            <p class="mb-4">Sebagai konsekuensinya muncul pergolakan pemikiran dalam tubuh HMI yang dalam berbagai substansi permasalahan timbul perbedaan pendapat, penafsiran dan interpretasi. Hal itu tercuat dalam bentuk seperti persoalan negara Islam, Islam Kaffah, sampai kepada penyesuaian dasar HMI dari Islam menjadi Pancasila. Sejak diberlakukannya Undang-Undang Nomor: 8 Tahun 1985 yang mengharuskan bahwa semua partai dan organisasi harus berdasarkan Pancasila. Kongres ke-16 HMI di Padang tahun 1986, HMI menyesuaikan diri dengan mengubah asas Islam dengan Pancasila. Akibat penyesuaian ini beberapa orang anggota HMI membentuk MPO (Majelis Penyelamat Organisasi-peny), akibatnya HMI pecah menjadi dua  yaitu HMI DIPO (karena sekretriatnya di jln. Diponegoro dan sekarang sudah di Jl. Sultan Agung-peny) dan HMI MPO.</p>
            <p class="mb-4"><b>Fase IX: Reformasi (1998-2000)</b></p>
            <p class="mb-4">Apabila dicermati dengan seksama secara secara historis HMI sudah mulai melaksanakan gerakan reformasi dengan menyampaikan beberapa pandangan yang berbeda serta kritik maupun evaluasi secara langsung terhadap pemerintahan Orde Baru di bawah kepemimpinan Presiden Soeharto pada tahun 1995. Sesuai dengan kebijakan PB HMI, bahwa HMI tidak akan melakukan tindakan-tindakan inkonstitusional dan konfrontasi terhadap Pemerintah. HMI melakukan dan menyampaikan kritik secara langsung yang bersifat konstruktif.</p>
            <p class="mb-4">Koreksi dan kritik yang dimaksud, pertama, disampaikan M. Yahya Zaini Ketua Umum PB HMI Periode 1992-1995 ketika memberikan kata sambutan pada pembukaan Kongres HMI ke-20 HMI di Istana Negara Jakarta tanggal 21 Januari 1995. Koreksi itu antara lain, bahwa menurut penilaian HMI, pembangunan ekonomi kurang diikuti dengan pembanguna politik. Masih dirasakan tingkat perubahan pada sistem politik tidak sebanding dengan perubahan ekonomi. Dalam pembangunan politik istitusi-isntitusi politik atau badan-badan demokrasi belum maksimal memainkan fungsi perannya. Akibatnya aspirasi masyarakat masih sering tersumbat (terhalang atau tidak sampai-peny). Kondisi inilah yang menuntut kita, pemerintah dan masyarakat untuk terus menggelindingkan (mewujudkan-peny) proses demokrasi dengan bingkai Pancasila tetapi ini harus diikuti dengan pemberdayaan masyarakat. Dalam suasana demikian, proses saling kontrol akan terbangun. Selain itu HMI melihat masih banyak distorsi dalam proses pembangunan. Gejala penyalah gunaan kekuasaan, kesewenang-wenangan, praktek kolusi, korupsi dan nepotisme (KKN-peny) adalah cerminan tidak berfungsi sistem nilai yang menjadi kontrol dan landasan etika dan bekerjanya suatu sistem.</p>
            <p class="mb-4">Suatu reformasi berikutnya dengan fokus yang lebih tajam, lugas dihadapan Presiden Soeharto tatkala menghadiri dan memberikan sambutan pada peringatan Ulang Tahun Emas 50 tahun HMI di Jakarta tanggal 20 Maret 1997 (satu tahun sebelum reformasi), dimana Taufik Hidayat Ketua Umum PB HMI 1995-1997 menegaskan; sekaligus jawaban atas kritik-kritik yang memandang HMI terlalu dekat dengan kekuasaan. Bagi HMI, kekuasaan atau politik bukanlah wilayah yang haram, politik justeru mulia, apabila dijalankan di atas etika dan bertujuan untuk menegakkan nilai-nilai kebenaran dan keadilan. Lantaran itu, HMI akan mendukung kekuasaan pemerintah yang sungguh-sungguh dalam meperjuangkan kebenaran dan keadilan. Sebaliknya, HMI akan tampil ke depan menentang kekuasaan yang korup dan menyeleweng. Inilah dibuktikan ketika HMI terlibat aktif dalam merintis dan menegakkan Orde Baru. Demikian juga pada saat sekarang ini dan masa-masa yang mendatang. Kritik-kritik ini tidak boleh mengurangi rasa percaya diri HMI untuk tetap melaksanakan amar ma’ruf dan nahi munkar.</p>
            <p class="mb-4">Pemikiran dan reformasi selanjutnya disampaikan Ketua Umum PB HMI 1997-1998 Anas Urbaningrum pada waktu peringatan Ulang Tahun HMI ke-51 di Graha Insan Cita Depok tanggal 22 Februari 1998, dengan judul Urgensi Reformasi Bagi Pembangunan Bangsa Yang Bermartabat. Pidato itu disampaikan 3 bulan sebelum lengsernya Presiden Soeharto 21 Mei 1998. Suara dan tuntutan reformasi telah dikumandangkan pula dalam berbagai aspek, yang disamapaikan Anas Urbaningrum pada peringatan ulang tahun ke-52 di Auditorium Sapta Pesona Departemen Parawisata Seni dan Budaya Jakarta 5 Februari 1999, dengan judul Dari HMI Untuk Kebersamaan Bangsa Menuju Indonesia Baru. Tuntutan reformasi juga disampaikan Ketua Umum PB HMI M. Fahruddin pada peringatan Ulangtahun HMI ke-53 di Taman Ismail Marzuki Jakarta, 5 Februari 2000 dengan judul “Merajut Kekuasaan Oposisi Membangun Demokrasi, Membangun Peradaban Baru Indonesia.”</p>
            <p class="mb-4"><b>Fase X: Tantangan II (2000-sekarang)</b></p>
            <p class="mb-4">Fase tantangan kedua ini muncul justru setelah Orde Reformasi berjalan dua tahun. Semestinya berdasarkan landasan-landasan atau sikap-sikap yang telah diambil PB HMI memasuki era reformasi semestinya HMI mengalami perkembangan yang signifikan menjawab berbagai tantangan sesuai dengan perannya sebagai organisasi perjuangan yang harus tampil sebagai pengambil inisiatif dalam memajukan kehidupan masyarakat, berbangsa dan bernegara. Akan tetapi justru sebaliknya HMI secara umum mengalami kemunduran, yang secara intensif disinyalir Agussalim Sitompul dalam bukunya 44 Indikator Kemunduruan HMI.</p>
            <p class="mb-4">Jika pada fase tantangan I (1964-1965) HMI dihadapkan pada tantangan eksternal yaitu menghadapi PKI, pada fase tantangan II ini HMI dihadapkan sekaligus pada dua tantangan besar secara internal dan eksternal sekaligus.</p>
            <p class="mb-4">Pertama, tantangan internal. Kajian tentang HMI saat ini menunjukkan bahwa dalam kehidupan sekarang dan mendatang, HMI ditantang: (a). Masalah eksistensi dan keberadaan HMI, seperti menurunnya jumlah mahasiswa baru masuk HMI, tidak terdapatnya HMI diberbagai perguruan tinggi, institut, fakultas, akademi, program studi, sebagai basis HMI. (b). Masalah relevansi pemikiran-pemikiran HMI, untuk melakukan perbaikan dan perubahan yang mendasar terhadap berbagai masalah yang muncul yang dihadapi bangsa Indonesia. (c). Masalah peran HMI sebagai organisasi perjuangan yang sanggup tampil dalam barisan terdepan sebagai avent grade, kader pelopor bangsa dalam mengambil inisiatif untuk melakukan berbagai perubahan yang sangat dibutuhkan masyarakat. (d). Masalah efektifitas HMI untuk memecahkan masalah yang dihadapi bangsa, karena banyak organisasi yang sejenis maupun yang lain, yang dapat dapat tampil lebih efektif dan dapat mengambil inisiatif terdepan untuk memberi solusi terhadap problem yang dihadapi bangsa Indonesia.</p>
            <p class="mb-4">Sebagai jawabannya, menurut perpecahan yang bersifat teoritis dan praktis, akan tetapi semuanya bersifat konseptual, integratif, inklusif. Sebab pendekatan yang tidak konseptual, parsial dan ekslusif tidak akan melahirkan jawaban yang efektif. Untuk itu dibutuhkan ide dan pemikiran dari anggota aktifitas kader, dan pengurus HMI di seluruh jenjang organisasi.</p>
            <p class="mb-4">Kedua, tantangan eksternal. Berbagai tantangan eksternal juga dihadapkan kepada HMI yang tidak skala besar dan rumitnya dari tantangan internal, antara lain: (a). Tantangan menghadapi perubahan jaman yang jauh berbeda dari abad ke-20 dan yang muncul pada abad ke-21 ini. (b). Tantangan terhadap peralihan generasi yang hidup  dalam jaman dan situasi yang berada dalam berbagai aspek kehidupan khususnya yang dijalani generasi muda bangsa. (c). Tantangan untuk mempersiapkan kader-kader dan alumni HMI, yang akan menggantikan alumni-alumni HMI yang saat ini menduduki berbagai posisi strategis dalam kehidupan bermasyarakat, berbangsa dan bernegara. Karena regenerasi atau pergantian pejabat-pejabat, suka tidak suka, mau tidak mau, pasti terus berlangsung. (d). Tantangan menghadapi bahaya abadi komunis. (e). Tantangan menghadapi golongan lain, yang mempunyai misi lain dari umat Islam dan bangsa Indonesia. (f). Tantangan tentang adanya kerawanan aqidah. (g). Tantangan menghadapi kemajuan ilmu pengetahuan dan teknologi, yang terus berkembang tanpa henti. (h). Tantangan menghadapi perubahan dan pembaharuan di segala aspek kehidupan manusia yang terus berlangsung sesuai dengan semangat kemajuan ilmu pengetahuan dan teknologi yang sangat kompetitif. (i). Tantangan menghadapi masa depan yang belum dapat diketahui bentuk dan coraknya. (j). Kondisi umat Islam di Indonesia yang dalam kondisinya belum bersatu. (k). Kondisi dan keadaan Perguruan Tinggi serta dunia kemahasiswaan, kepemudaan, yang penuh dengan berbagai persoalan dan problematika yang sangat kompleks. (l). Tantangan HMI menuju Masyarakat Ekonomi Asean (peny). (m). Tantangan menghadapi politik Indonesia yang tidak kondusif dan tidak membangun karakter kebangsaan Indonesia.</p>
            <p class="mb-4">Pada fase tantangan II ini, nampaknya HMI semakin memudar dan mundur yang telah berlangsung 25 tahun sejenak, dari tahun 1980-2005. HMI tidak mampu bangkit secara signifikan, bahkan dalam dua periode terakhir PB HMI mengalami perpecahan. Karena itu, menghadapi tantangan tersebut, HMI dengan segenap aparatnya harus mampu menghadapinya dengan penuh semangat dan militansi yang tinggi. Apakah HMI mampu menghadapi tantangan itu, sangat ditentukan oleh pemegang kendali organisasi sejak dari PB HMI, Pengurus Badko HMI, Cabang HMI, Korkom HMI, Komisariat, Lembaga-Lembaga Kekaryaan, serta segenap anggota HMI, maupun alumninya yang tergabung dalam KAHMI sebagai penerus, pelanjut serta penyempurna mission sacre HMI. Peralihan jaman, peralihan generasi, saat ini menentukan bagi eksistensi HMI di masa mendatang.</p>
            <p class="mb-4"><b>Fase XI: Kebangkitan Kembali</b></p>
            <p class="mb-4">Gelombang kritik terhadap HMI tentang kemundurannya telah menghasilkan dua umpan balik. Pertama, telah muncul kesadaran individual dan kesadaran kolektif (bersama-peny) di kalangan anggota, aktivis, kader, bahkan alumni HMI serta pengurs dimulai dari Komisariat sampai PB HMI, bahwa HMI sedang mengalami kemunduran. Kedua, selanjutnya dari kesadaran itu muncul kesadaran baru, baik secara individual dan kesadaran bersama dikalangan anggota, aktivis, kader, alumni dan pengurus bahwa dalam tubuh HMI mutlak dilakukan perubahan dan pembaharuan supaya dapat bangkit kembali seperti masa jaya-jaya dulu.</p>
            <p class="mb-4">Sampai sejauh mana kebenaran dan bukti adanya indikator-indikator kebangkitan kembali HMI, sejarahlah yang akan menentukan kelak. Kita semua berharap dengan penuh optimis sesuai dengan ajaran Islam supaya manusia bersikap optimis, agar HMI dapat mengakhiri masa kemundurannya dan memasuki masa kebangkitannya secara meyakinkan.</p>
            <p class="mb-4">Di tangan generasi sekaranglah sebagai generasi penerus, pelanjut, dan penyempurna perjuangan organisasi mahasiswa Indonesia tertua ini (HMI). Yakinkan dengan Iman, Usahakan dengan Ilmu, Sampaikan dengan Amal, Bahagia HMI, Jayalah Kohati, Yakin Usaha Sampai.</p>
          </div>
        </div>
      </article>
      
    </div>
  </div>
</div>








<?php if (isset($component)) { $__componentOriginal99051027c5120c83a2f9a5ae7c4c3cfa = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal99051027c5120c83a2f9a5ae7c4c3cfa = $attributes; } ?>
<?php $component = App\View\Components\Footer::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Footer::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal99051027c5120c83a2f9a5ae7c4c3cfa)): ?>
<?php $attributes = $__attributesOriginal99051027c5120c83a2f9a5ae7c4c3cfa; ?>
<?php unset($__attributesOriginal99051027c5120c83a2f9a5ae7c4c3cfa); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal99051027c5120c83a2f9a5ae7c4c3cfa)): ?>
<?php $component = $__componentOriginal99051027c5120c83a2f9a5ae7c4c3cfa; ?>
<?php unset($__componentOriginal99051027c5120c83a2f9a5ae7c4c3cfa); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\latihan-laravel\resources\views/about.blade.php ENDPATH**/ ?>