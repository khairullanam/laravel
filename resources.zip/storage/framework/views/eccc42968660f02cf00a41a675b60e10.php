<?php if (isset($component)) { $__componentOriginal1f9e5f64f242295036c059d9dc1c375c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1f9e5f64f242295036c059d9dc1c375c = $attributes; } ?>
<?php $component = App\View\Components\Layout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Layout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1f9e5f64f242295036c059d9dc1c375c)): ?>
<?php $attributes = $__attributesOriginal1f9e5f64f242295036c059d9dc1c375c; ?>
<?php unset($__attributesOriginal1f9e5f64f242295036c059d9dc1c375c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1f9e5f64f242295036c059d9dc1c375c)): ?>
<?php $component = $__componentOriginal1f9e5f64f242295036c059d9dc1c375c; ?>
<?php unset($__componentOriginal1f9e5f64f242295036c059d9dc1c375c); ?>
<?php endif; ?>
<section class="bg-white py-64">
  <div class="max-w-4xl mx-auto bg-white shadow-xl rounded-lg p-6" data-aos="fade-down" data-aos-duration="2000">
      <h1 class="text-4xl text-center font-bold text-black mb-6">E-BOOKS Paramadina</h1>

      <!-- Accordion for HMI -->
      <div class="accordion">
          <div class="border-b">
              <button 
                  onclick="toggleAccordion('hmiAccordion')" 
                  class="w-full text-left text-lg font-semibold py-4 px-6 rounded-xl shadow-md text-white gradient focus:outline-none"
                  id="hmiButton" data-aos="fade-down" data-aos-duration="1000"
              >
                  Ke-Perempuanan
              </button>
              <div id="hmiAccordion" class="hidden" data-aos="fade-down">
                  <?php $__empty_1 = true; $__currentLoopData = $perempuanEbooks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ebook): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                      <div class="p-4 border-t flex items-center justify-between bg-gray-50 rounded-lg shadow-sm">
                        <div>
                          <p class="text-lg font-medium text-gray-900"><?php echo e($ebook->title); ?></p>
                          <p class="text-sm text-gray-600">Size: 1.2 MB</p>
                        </div>
                        <a 
                          href="file/hmi/<?php echo e($ebook->file); ?>" 
                          download 
                          class="px-4 py-2 gradient text-white text-sm font-medium rounded-lg shadow"
                        >
                          Download
                        </a>
                      </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                      <div class="p-4 text-gray-600">Tidak ada e-book HMI tersedia.</div>
                  <?php endif; ?>
              </div>
          </div>
      </div>
  </div>
</section>

<script>
  // Fungsi untuk membuka accordion
  function toggleAccordion(id) {
      const element = document.getElementById(id);
      if (element.classList.contains('hidden')) {
          element.classList.remove('hidden');
      } else {
          element.classList.add('hidden');
      }
  }

  // Menambahkan logika untuk membuka accordion berdasarkan kategori yang dipilih
  document.addEventListener('DOMContentLoaded', function() {
      const category = "<?php echo e($category); ?>";

      if (category === 'hmi') {
          document.getElementById('hmiButton').click(); // Membuka accordion HMI
      } else if (category === 'ke-islaman') {
          document.getElementById('keIslamanButton').click(); // Membuka accordion Ke-Islaman
      } else if (category === 'ke-indonesiaan') {
          document.getElementById('keIndonesiaanButton').click(); // Membuka accordion Ke-Indonesiaan
      }
  });
</script>



  
 
  
  
 <?php if (isset($component)) { $__componentOriginal99051027c5120c83a2f9a5ae7c4c3cfa = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal99051027c5120c83a2f9a5ae7c4c3cfa = $attributes; } ?>
<?php $component = App\View\Components\Footer::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Footer::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal99051027c5120c83a2f9a5ae7c4c3cfa)): ?>
<?php $attributes = $__attributesOriginal99051027c5120c83a2f9a5ae7c4c3cfa; ?>
<?php unset($__attributesOriginal99051027c5120c83a2f9a5ae7c4c3cfa); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal99051027c5120c83a2f9a5ae7c4c3cfa)): ?>
<?php $component = $__componentOriginal99051027c5120c83a2f9a5ae7c4c3cfa; ?>
<?php unset($__componentOriginal99051027c5120c83a2f9a5ae7c4c3cfa); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\latihan-laravel\resources\views/ebook-kohati.blade.php ENDPATH**/ ?>