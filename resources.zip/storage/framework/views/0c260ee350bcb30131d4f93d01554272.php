
<img class="w-28" src="/img/logo-1.png" alt=""><?php /**PATH C:\laragon\www\latihan-laravel\resources\views/components/application-logo.blade.php ENDPATH**/ ?>